
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>

struct task_struct *task; //This struct represents the PCB
void tasklist_iterator(void)
{
	/*This function iterates through the tasks and print them - Implementation of Part1*/
	for_each_process(task)
	{ 
	/* on each iteration task points to the next task */ 
	printk("name: %s, pid: [%d], state: %li\n", task->comm, task->pid, task->state);

	} 
}
void DFS(struct task_struct *task)
{
	/*This function constructs the DFS tree of tasks-Implementation of part2 */
    struct task_struct *child;
    struct list_head *list;
    printk("name: %s, pid: [%d], state: %li\n", task->comm, task->pid,task->state);
    list_for_each(list, &task->children) {
	
        child= list_entry(list, struct task_struct, sibling);
        DFS(child);
    }
}
int DFS_tasklist_init(void)
{
	/*this function is the loader module*/
    printk(KERN_INFO "Loading the DFS Tasklist iterator Module\n");
    tasklist_iterator();
    printk(KERN_INFO "listing the processes in DFS style\n");
    DFS(&init_task);
    return 0;
}

void DFS_tasklist_exit(void)
{
	/*This function is the remover module*/
    printk(KERN_INFO "Exiting Task Lister Module...\n");
}

/*Register the created modules*/
module_init(DFS_tasklist_init);
module_exit(DFS_tasklist_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("DFS_TASKSLIST Module");
MODULE_AUTHOR("JANANI_SHADI");
